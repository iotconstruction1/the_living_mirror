import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(LivingMirrorApp());
}

class LivingMirrorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'The Living Mirror',
      theme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.blueGrey,
        fontFamily: 'Roboto',
      ),
      home: HomeScreen(),
    );
  }
}